package ru.app.services.device;

class InitializationException extends Throwable{
}
