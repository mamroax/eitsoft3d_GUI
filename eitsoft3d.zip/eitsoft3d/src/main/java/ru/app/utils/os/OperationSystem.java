package ru.app.utils.os;

public interface OperationSystem {
    String getComPort();
}
